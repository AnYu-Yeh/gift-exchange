document.querySelectorAll('form[data-confirm]').forEach(form => {
  form.addEventListener('submit', event => {
    if (!window.confirm(form.dataset.confirm)) event.preventDefault();
  });
});
document.querySelectorAll('input[type=file]').forEach(input => {
  input.addEventListener('change', () => {
    input.setCustomValidity(input.files[0]?.size > 5 * 1024 * 1024 ? '圖片請小於 5 MB。' : '');
    input.reportValidity();
  });
});
